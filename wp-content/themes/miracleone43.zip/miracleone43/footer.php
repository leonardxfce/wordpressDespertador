
		<footer class="footer-distributed">

			<div class="footer-left">

				<img width="200px" src="<?php bloginfo('template_url')?>/img/bannernuevo.png" alt="Despertador Online" >

				<p class="footer-links">
					<a href="www.despertadorlavalle.com.ar">Inicio</a>
					·
					<a href="<?php bloginfo('url');?>/category/titulares/">Titulares</a>
					·
					<a href="<?php bloginfo('url');?>/category/radio/">FM 89.1</a>
					·
					<a href="<?php bloginfo('url');?>/category/servicios/">Servicios</a>
					·
					<a href="#">Publicidad</a>
					·
					<a href="#">Contacto</a>
				</p>
                <div class="datos-contacto" style="color:white;">
                    <p><i class="fa fa-map-pin"></i> Domicilio: Bolivar 47</p>
                <p><i class="fa fa-phone"></i> Teléfono (Argentina) : +54 0261 494 1850</p>
                <p><i class="fa fa-envelope"></i> E-mail : eldespertador2002@gmail.com</p>
				<p class="footer-company-name">Periodico el Despertador &copy; 2018</p>
                </div>

				<div class="footer-icons">

					<a href="https://www.facebook.com/PeriodicoElDespertador/"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/PDespertador"><i class="fa fa-twitter"></i></a>

				</div>

			</div>

			<div class="footer-right">

				<p>Dejanos tu mensaje</p>

				<form action="mailto:eldespertador2002@gmail.com" method="post">

					<input type="text" name="email" placeholder="Email" />
					<textarea name="message" placeholder="Mensaje"></textarea>
					<button>Enviar</button>

				</form>

			</div>

		</footer>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-113891225-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'UA-113891225-1');
        </script>

    <script src="<?php bloginfo('template_url')?>/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_url')?>/js/mdb.min.js"></script>
    <script src="<?php bloginfo('template_url')?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?php bloginfo('template_url')?>/js/main.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='https://cdn.rawgit.com/monkeecreate/jquery.simpleWeather/master/jquery.simpleWeather.min.js'></script>
    <script src="<?php bloginfo('template_url')?>/js/clima.js"></script>
    <script src="<?php bloginfo('template_url')?>/js/clima2.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
     <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/clima.js" type="text/javascript"></script>
        <![endif]-->
         <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/main.js" type="text/javascript"></script>
        <![endif]-->
         <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/jquery-3.2.1.min.js" type="text/javascript"></script>
        <![endif]-->
         <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js" type="text/javascript"></script>
        <![endif]-->
     <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/mdb.min.js" type="text/javascript"></script>
        <![endif]-->
        <!--[if lt IE 9]>
        <script src="/<?php echo get_template_directory_uri(); ?>/js/clima2.js" type="text/javascript"></script>
        <![endif]-->

</body>
</html>