<?php get_header();?>

<?php include 'seccion-uno.php' ?>
<?php include 'seccion-dos.php' ?>
<?php include 'seccion-tres.php' ?>
<?php include 'seccion-cuatro.php' ?>
<?php include 'seccion-cinco.php' ?>
<?php include 'seccion-19.php' ?>
<?php include 'seccion-seis.php' ?>
<?php include 'seccion-siete.php' ?>
<?php include 'seccion-nueve.php' ?>
<?php include 'seccion-diez.php' ?>
<?php include 'seccion-once.php' ?>
<?php include 'seccion-doce.php' ?>
<?php include 'seccion-trece.php' ?>
<?php include 'seccion-catorce.php' ?>
<?php include 'seccion-quince.php' ?>
<?php include 'seccion-dieciseis.php' ?>
<?php include 'seccion-diecisiete.php' ?>
<?php include 'seccion-dieciocho.php' ?>


<?php get_footer(); ?>