

<!-- Newsletter -->
<div class="newletter" >
    <div >
        <h1>Newsletter</h1>
        <hr>
    </div>

	
    <form class="wrapper" method="POST" action="../../subidas/newsletter.php">
        <input type="email" placeholder="Ingrese su mail.">
        <input type="submit"  name="Subcribirme" class="btn btn-default dropdown-toggle" value="Subcribirme">
	</form>
</div>
<!-- Newsletter -->