var corriente;


corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
console.log("Hola mundo");
console.log(corriente);

corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
corriente=document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "";
if(document.getElementsByClassName("highlightedDate fitText")[0] == "Current"){
    document.getElementsByClassName("highlightedDate fitText")[0].innerHTML = "Corriente";

}
