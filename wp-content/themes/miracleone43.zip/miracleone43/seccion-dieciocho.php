

<!-- SECCION 9 -->
<div class="container-seccion9">
    <div class="titulo-edicion">
        <h1>Edición Impresa</h1>
    </div>

    <div class="contenido-edicion">
        <?php periodico(); ?>
    </div>
</div>
<!-- SECCION 9 -->